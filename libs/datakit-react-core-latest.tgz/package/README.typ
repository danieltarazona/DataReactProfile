#import "template.typ": *

#show: project.with(
  title: "DataKit React UI Core",
  subtitle: "Scientific Architecture & Operations Manual",
  authors: (
    (name: "Daniel Tarazona", email: "contact@danieltarazona.com", affiliation: "Lead Engineer"),
  ),
  date: "January 16, 2026",
  version: "1.1.2"
)

= Abstract

DataKit React UI Core represents a paradigm shift in UI component architectures. Moving away from purely reactive, effect-driven models, it embraces **Finite State Machines (FSM)** via XState to guarantee deterministic behavior in complex interface interactions. Coupled with a proprietary, serverless supply chain built on the **Cloudflare Edge**, it offers a fully controlled, high-performance distribution mechanism that bypasses public registries. This manual details the theoretical foundations, implementation specifics, and operational workflows of the ecosystem.

= 1. Theoretical Foundations

== 1.1 The Problem with "Effect-Driven" UI

Modern React development often suffers from "boolean soup"---components cluttered with `isOpening`, `isClosing`, `isVisible`, `hasError` flags. Managing the combinatorial explosion of these states leads to inevitable bugs and impossible states (e.g., `isLoading: true` but `error: "Network Error"`).

== 1.2 The State Machine Solution

DataKit adopts **Automata Theory** as a first-class citizen. Components like Dialogs, Tabs, and Toggles are backed by XState machines.

$ M = (Q, Sigma, delta, q_0, F) $

Where:
- $Q$: Finite set of states (e.g., `closed`, `opening`, `open`).
- $Sigma$: Finite set of input events (e.g., `TRIGGER_CLICK`, `ANIMATION_END`).
- $delta$: Transition function $delta: Q times Sigma -> Q$.

This ensures mathematically rigorously that a component *cannot* transition from `closed` to `closing`, eliminating entire classes of runtime errors.

= 2. Architecture

== 2.1 Technology Stack

The library utilizes a "Bleeding Edge" stack optimized for performance and type safety:

- **Runtime**: React 19 (Concurrent Features, Server Components).
- **Language**: TypeScript 5.x (Strict Mode).
- **Styling**: Tailwind CSS v4 (Zero-runtime, compiler-based).
- **Bundler**: Rolldown (Rust-based, millisecond build times).
- **Motion**: Framer Motion (Physics-based animations).

== 2.2 Directory Structure

```text
DataKitReactCore/
├── src/                  # Source Code
│   ├── machines/         # XState Definitions
│   ├── components/       # React Components
│   └── themes/           # Design Tokens (Audi, Apple, Puma)
└── dist/                 # Build Artifacts (ESM/CJS)
```



= 3. Operational Workflows & Scripts

Detailed workflows of the automated lifecycle scripts in `package.json`.

== 3.1 Build Pipeline (`npm run build`)

Compiles the library into multiple formats and generates documentation assets.

```mermaid
graph TD
    Start([Execute: pnpm run build]) --> TSC[TypeScript Compiler]
    TSC -->|Check| Vite[Vite Build]
    
    subgraph "Vite Build Process"
        Vite -->|Input| Entry[src/index.ts]
        Vite -->|Rolldown| ESM[dist/*.js (ESM)]
        Vite -->|Rolldown| CJS[dist/*.cjs (CommonJS)]
        Vite -->|Plugin| DTS[dist/*.d.ts (Types)]
        Vite -->|PostCSS| CSS[dist/*.css]
    end

    Vite --> SB[Storybook Build]
    SB --> SBOut[storybook-static/]
    
    Vite --> Demo[Vite Demo Build]
    Demo --> DemoOut[dist-demo/]
    
    SBOut & DemoOut --> End([Build Complete])
```

== 3.2 Publication Pipeline (`npm run publish:private`)

The core script that versions, packs, and uploads the library to our private cloud. This now utilizes the shared `scripts/publish-library.ts` from the `DataKitNPMRegistry` repository to ensure consistency across packages.

= 4. Dependencies Analysis

A breakdown of critical dependencies and their justification:

- **`@xstate/react`**: Provides the `useMachine` hook to integrate FSMs into React's render cycle.
- **`motion`**: Chosen over CSS transitions for its ability to handle spring physics and unmount animations (`AnimatePresence`), essential for complex UI.

= 5. Storybook & Demo

Documentation is treated as a separate build artifact.

- **Storybook**: Component isolation workshop. Synced to `registry/storybook`.
- **Demo App**: A consumer application proving integration. Synced to `registry/demo`.

Both are served as static assets from the same Worker, routed via `/storybook/*` and `/demo/*`.

= 6. Future Roadmap

1.  **NPM Protocol Compatibility**: Implementing full `npm install` compatibility to remove the need for `sync` scripts.
2.  **Edge Caching**: Implementing `Cache-Control` logic to cache tarballs in user's ISP datacenters.
3.  **Binary Patching**: Distributing only deltas between versions to save bandwidth.

#pagebreak()
#align(center)[_DataKit React UI Core - Engineering Manual_]
